Ambiente:
	$ Python 3.8.5

Bibliotecas:
	- sys
	- random
	- libnum
	- Crypto
	- base64
	- math
	- hashlib

Executar:
	$ python3 src/main.py 512